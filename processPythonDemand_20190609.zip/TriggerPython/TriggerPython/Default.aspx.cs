﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TriggerPython
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Btn_Send1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process p = new System.Diagnostics.Process();
            string ExecFilePath = @"C:\Users\KKMAN\AppData\Local\Programs\Python\Python37\";
            string strExecCommand = String.Empty;
            int returnCode = 0;
            string strStdError = String.Empty;
            StringBuilder myStringBuilder = new StringBuilder();
            string strResult = String.Empty;

            strExecCommand = " python ";

            p.StartInfo.FileName = ExecFilePath;
            p.StartInfo.Arguments = strExecCommand;

            p.StartInfo.UseShellExecute = false; // 必須被設定為 False，以便直接導出結果

            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.RedirectStandardError = true;
            p.StartInfo.RedirectStandardInput = true;

            p.StartInfo.CreateNoWindow = true;
            p.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;

            p.StartInfo.WorkingDirectory = StripFilenameFromFullPath(p.StartInfo.FileName);

            p.OutputDataReceived += (pSender, args) =>
            {
            };

            p.Start();
            p.BeginOutputReadLine();
            strStdError = p.StandardError.ReadToEnd();
            returnCode = p.ExitCode;

            if (returnCode == 0)
            {
                p.Close();
            }
            else
            {
                // 出現錯誤
                if (!String.IsNullOrEmpty(strStdError))
                {
                    myStringBuilder.AppendLine(strStdError);
                    strResult = myStringBuilder.ToString();
                }
            }
        }

        private static string StripFilenameFromFullPath(string ExeFilePath)
        {
            int CharIndex = -1;

            CharIndex = ExeFilePath.LastIndexOf(@"\");

            if (CharIndex != -1)
            {
                ExeFilePath = ExeFilePath.Substring(0, CharIndex);
            }

            return ExeFilePath;
        }

        protected void Btn_Send2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"C:\Tmpx\HelloWorld.py");
        }
    }
}