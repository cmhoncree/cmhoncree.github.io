﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.IO;

namespace TriggerPython
{
    /// <summary>
    /// ShowImage 的摘要描述
    /// </summary>
    public class ShowImage_Backup : IHttpHandler
    {
        // 既有檔案儲存目錄相對路徑
        // string strTmpFolder = @"C:\Tmpx\";
        string strTmpFolder = HttpContext.Current.Server.MapPath("~/Tmpx/");
        string thumbnailImageFileName_Png = ".png";
        int int_Width = 640;
        int int_Height = 480;

        string oriImgFilePath = String.Empty;
        string copyImgFilePath = String.Empty;
        string newImgFilePath = String.Empty;

        public void ProcessRequest(HttpContext context)
        {
            // 取得系統編號
            string strsIndex = Convert.ToString(context.Request.QueryString["sIndex"]);
            // string strNewsIndex = Convert.ToString(context.Request.QueryString["NewsIndex"]);

            // 產生複製用的檔案名稱
            string strCopysIndex = Guid.NewGuid().ToString();
            string strNewsIndex = Guid.NewGuid().ToString();

            string strTmpImageDir = "~/Images/";
            string strTmpImageFileName = "drag.png";

            // 建立 FileStream 物件，讀取既有圖檔
            // FileStream myFileStream_Read = null;
            // 建立 FileStream 物件，複製既有圖檔
            // FileStream myFileStream_Write = null;
            // 建立 FileStream 物件，準備將上述串流中的資料寫出，以便產生新檔案
            // BinaryWriter myBinaryWriter = null;
            FileInfo myFileInfo = null;
            // MemoryStream myMemoryStream_Write = null;

            byte[] bt = null;
            // bool isFileLock = true;

            string strCopyFileCommand = String.Empty;

            // if (strsIndex == null || strNewsIndex == null)
            if (strsIndex == null)
            {
                bt = File.ReadAllBytes(HttpContext.Current.Server.MapPath(strTmpImageDir) + strTmpImageFileName);
                OutputToHtml(bt);
            }
            else
            {
                oriImgFilePath = strTmpFolder + strsIndex + thumbnailImageFileName_Png;
                copyImgFilePath = strTmpFolder + strCopysIndex + thumbnailImageFileName_Png;
                newImgFilePath = strTmpFolder + strNewsIndex + thumbnailImageFileName_Png;

                /*
                Image image1 = Image.FromFile(oriImgFilePath);
                */


                if (File.Exists(oriImgFilePath))
                {
                    myFileInfo = new FileInfo(oriImgFilePath);

                    while (true)
                    {
                        if (myFileInfo.Length > 0)
                        {
                            strCopyFileCommand = "copy " + oriImgFilePath + " " + copyImgFilePath;
                            System.Diagnostics.Process.Start(strCopyFileCommand);
                            break;
                        }

                        System.Threading.Thread.Sleep(3);
                    }

                    /*
                    isFileLock = checkFileLockStatus(oriImgFilePath);

                    while (true)
                    {
                        if (isFileLock)
                        {
                            System.Threading.Thread.Sleep(3);
                            checkFileLockStatus(oriImgFilePath);
                        }
                        else
                        {
                            break;
                        }
                    }

                    bt = File.ReadAllBytes(oriImgFilePath);
                    File.WriteAllBytes(copyImgFilePath, bt);
                    */
                }

                // writeImageToHtml(oriImgFilePath, oriImgFilePath, int_Width, int_Height, "png");
            }
        }

        private bool checkFileLockStatus(string strFilePath)
        {
            bool isFileLock = true;

            try
            {
                using (Stream stream = new FileStream(strFilePath, FileMode.Open))
                {
                    isFileLock = false;
                }
            }
            catch
            {
                isFileLock = true;
            }

            return isFileLock;
        }

        private void writeImageToHtml(string _oriImgFilePath, string _newImgFilePath, int _width, int _height, string _imgType)
        {
            // 建立 MemoryStream 物件
            MemoryStream myStream = new MemoryStream();

            // 建立 Bitmap 物件，代表原本的圖檔
            Bitmap oldBitmap = null;

            // 建立 Bitmap 物件，代表新的圖檔，並設定特定的大小
            Bitmap newBitmap = null;

            oldBitmap = new Bitmap(_oriImgFilePath);
            newBitmap = new Bitmap(oldBitmap, _width, _height);

            // 釋放原本的圖檔
            oldBitmap.Dispose();

            // 將新的圖檔儲存至串流中
            if (_imgType == "jpeg")
            {
                newBitmap.Save(myStream, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            else if (_imgType == "jpg")
            {
                newBitmap.Save(myStream, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            else if (_imgType == "png")
            {
                newBitmap.Save(myStream, System.Drawing.Imaging.ImageFormat.Png);
            }
            else if (_imgType == "bmp")
            {
                newBitmap.Save(myStream, System.Drawing.Imaging.ImageFormat.Bmp);
            }
            else if (_imgType == "gif")
            {
                newBitmap.Save(myStream, System.Drawing.Imaging.ImageFormat.Gif);
            }

            // 建立 FileStream 物件，準備將上述串流中的資料寫出，以便產生新檔案
            FileStream myFs = File.OpenWrite(_newImgFilePath);

            // 將上述串流中的資料轉成 byte 陣列
            byte[] newBitmapData = myStream.ToArray();

            // 將串流中的資料寫出，以便產生新檔案
            myFs.Write(newBitmapData, 0, newBitmapData.Length);

            // 關閉 FileStream 物件
            myFs.Close();

            // 將新的圖檔轉成陣列資料
            byte[] bt = ReadAllBytesToArray(_newImgFilePath);

            OutputToHtml(bt);
        }

        private void OutputToHtml(byte[] bt)
        {
            // 停止圖片暫存機制
            HttpContext.Current.Response.Expires = 0;
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);

            // 設定 HTTP 檔頭的輸出格式
            HttpContext.Current.Response.ContentType = "Images/PNG";
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.BufferOutput = false;

            // 將陣列資料寫入輸出資料流，以便顯示在畫面上
            HttpContext.Current.Response.BinaryWrite(bt);
            HttpContext.Current.Response.Flush();
        }

        private byte[] ReadAllBytesToArray(string path)
        {
            byte[] buffer = null;
            FileStream stream = null;

            try
            {
                int offset = 0;
                stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);

                if (stream.Length > int.MaxValue)
                {
                    throw (new IOException("檔案太大，無法下載，請確認。"));
                }

                int bytesToRead = Convert.ToInt32(stream.Length);
                buffer = new byte[stream.Length];

                while (bytesToRead > 0)
                {
                    int bytesRead = stream.Read(buffer, offset, bytesToRead);

                    if (bytesRead == 0)
                    {
                        throw new IOException("非預期之檔案結尾，讀取檔案失敗!");
                    }

                    offset = (offset + bytesRead);
                    bytesToRead = (bytesToRead - bytesRead);
                }
            }
            finally
            {
                if (stream != null)
                {
                    stream.Close();
                }
            }

            return buffer;
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}