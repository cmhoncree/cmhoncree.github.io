import pyodbc;
import getpass;
import matplotlib.pyplot as plt;

## 讀取畫面上參數並顯示
import sys;
import os;
######################################

######################################
## 讀取畫面上參數並顯示
#Source:https://stackoverflow.com/questions/17544307/how-do-i-run-python-script-using-arguments-in-windows-command-line
######################################

## 讀取畫面上參數並顯示
######################################
def hello(a, b):
	print("hello and that's your sum:")
	sum = a+b
	print(str(sum))

#if __name__== "__main__":
#	hello(int(sys.argv[1]), int(sys.argv[2]))
######################################

## 讀取數據並繪圖
######################################
#listx = [1, 5, 7, 9, 13, 16];
#listy = [15,50,80,40,70,50];

## 建立 Plot 圖形
#plt.plot(listx,listy);

#fig1 = plt.gcf();

## 繪製圖形 
#plt.draw();

## 將圖形儲存至檔案中
#fig1.savefig('Result.jpg', dpi=100);

## 顯示圖形
#plt.show();
######################################

data_List1 = [];
data_List2 = [];

imageSaveDir = 'D:\Tmpx';
## 取得 Python 程式所在的目錄
#imageSaveDir = os.path.dirname(os.path.realpath(__file__));

print(imageSaveDir);

def query_database(cursor, imgHeadName, queryCondition1, queryCondition2):
	## 組合 SQL 指令
	col_sql = "SELECT [Shrinkagdt], [shrinkage_strain] FROM [Tw_SCC_NU_SCC_Data] WHERE [Shrinkagdt] >= '{0}' AND [shrinkage_strain] <='{1}'".format(queryCondition1, queryCondition2);
	
	## 顯示 SQL 指令
	print(col_sql);
	
	## 執行 SQL 指令
	cursor.execute(col_sql);
	
	## 取得所有資料
	rows = cursor.fetchall();
	
	 ## 關閉 Cursor
	cursor.close();
	
	for row in range(0, len(rows)):
		data_List1.append(rows[row][0]);
		data_List2.append(rows[row][1]);
		
	print("所選數據共有: ", len(rows), "筆");
	draw_save(imgHeadName);
	
	#toshow = input("是否顯示所選數據? (輸入'Y' 或任意鍵跳過)")

	#if toshow == 'Y' or toshow == 'y':
	#	print(data_List1);
	#	print("/");
	#	print(data_List2);
	#else:
	#	print("程式繼續")
		
	#return data_List1    
	
def draw_save(imgHeadName):
	## 建立 Plot 圖形
	plt.plot(data_List1, data_List2);

	fig1 = plt.gcf();

	## 繪製圖形 
	plt.draw();

	## 將圖形儲存至檔案中
	#fig1.savefig(imageSaveDir + '\\' + imgHeadName + '.png');
	plt.savefig(imageSaveDir + '\\' + imgHeadName + '.jpg')

	## 顯示圖形
	#plt.show();
	

## 連接資料庫
def db_conn(username, password, imgHeadName, queryCondition1, queryCondition2):
	server = '(local)\SQLEXPRESS'
	database = 'NTU_Creep' 
	cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';UID=' + username + ';PWD=' + password);

	## 建立 Cursor
	cursor = cnxn.cursor()
	print("MS-SQL has connected")
	
	#選擇資料表
	#tbname = get_table_name(cursor)
	#選擇欄位
	#get_column_name(cursor, tbname)  

	# 查詢資料
	query_database(cursor, imgHeadName, queryCondition1, queryCondition2);

## 以 SQL Server 驗證登入 SQL Server
user = 'NTU_Creep_User'
pwd = 'tester1115'

## 參數1:圖片檔案名稱
## 參數2:查詢條件1
## 參數3:查詢條件2
if __name__== "__main__":
	db_conn(user, pwd, sys.argv[1], sys.argv[2], sys.argv[3]);