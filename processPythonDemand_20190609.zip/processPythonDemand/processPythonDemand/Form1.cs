﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace processPythonDemand
{
    public partial class Form1 : Form
    {
        // 既有檔案儲存目錄相對路徑
        string strTmpFolder = @"D:\Tmpx\";
        string thumbnailImageFileName_Png = ".png";
        string thumbnailImageFileName_Jpg = ".jpg";
        int int_Width = 640;
        int int_Height = 480;

        System.Timers.Timer myTimer = new System.Timers.Timer();

        public Form1()
        {            
            InitializeComponent();

            myTimer.Enabled = true;
            // 處理時間
            myTimer.Interval = 1000;
            myTimer.Elapsed += new System.Timers.ElapsedEventHandler(this.myTimer_Tick);

            // 啟動計時器
            myTimer.Start();
        }

        private void myTimer_Tick(object sender, EventArgs e)
        {
            Ntu_CreepDataContext myNtu_CreepDataContext = new Ntu_CreepDataContext();
            string strCommand = strTmpFolder + "DrawAndSave.py ";
            string oldImgFilePath = String.Empty;

            List<QueryConditionRecord> myQueryConditionRecordList = (from Item in myNtu_CreepDataContext.QueryConditionRecord
                                                                     where Item.isDone != true
                                                                     select Item).ToList();

            if (myQueryConditionRecordList.Count > 0)
            {
                // 停止計時器
                myTimer.Stop();

                foreach (QueryConditionRecord Item in myQueryConditionRecordList)
                {
                    System.Diagnostics.Process.Start(strCommand, Item.sIndex + " " + Item.queryCondition1 + " " + Item.queryCondition2);
                    oldImgFilePath = strTmpFolder + Item.sIndex + thumbnailImageFileName_Jpg;

                    while (true)
                    {
                        // 判斷檔案是否存在
                        if (System.IO.File.Exists(oldImgFilePath))
                        {
                            // 檔案已經存在
                            Item.isDone = true;
                            break;
                        }
                        else
                        {
                            System.Threading.Thread.Sleep(3);
                        }
                    }
                }

                myNtu_CreepDataContext.SubmitChanges();

                // 啟動計時器
                myTimer.Start();
            }
        }
    }
}
