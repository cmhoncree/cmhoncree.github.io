
# coding: utf-8
# In[10]:


#!pip install pyodbc
import pyodbc 
import getpass 
#import sklearn.datasets as sd
#import numpy as np
import matplotlib.pyplot as plt


# In[11]:


#Get table name
def get_table_name(cursor):
    dbname_sql = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES ORDER BY TABLE_NAME"
    cursor.execute(dbname_sql)
    tbname_list = cursor.fetchall()
    ans = input("是參考全部的Table名稱?(輸入:'Y'或任意鍵跳過)")
    if ans == 'Y' or ans == 'y':
        print("以下為資料庫Table列表:")
        for tb in range(0,len(tbname_list)):
            print(tb,":", tbname_list[tb][0])
    else:
        print("電梯向下")
    tbname = input("請輸入要選擇的Table名稱:") 
    return tbname

#Get column name
def get_column_name(cursor,tbname):
    tbname_sql = "SELECT COLUMN_NAME,ORDINAL_POSITION,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '{0}'".format(tbname)
    cursor.execute(tbname_sql)
    tbname_list = cursor.fetchall()
    print("--------------------------")
    print("以下為Table欄位名稱:")
    print("--------------------------")
    for col in range(0,len(tbname_list)):
        print(col,":", tbname_list[col][0])

    
#Select column    
def select_column(cursor, tbname):
    print("--------------------------")
    print("請輸入要擷取的資料欄位及範圍")
    print("--------------------------")
    col_name = input("請輸入欄位名稱: ")
    col_condi = input("請輸入SQL範圍指令(Where ...) or 不選擇(輸入no): ")
    print("--------------------------")
    if col_condi == 'no':
        col_sql = "SELECT {0} FROM {1}".format(col_name, tbname)
        print(col_sql)
    else:
        col_sql = "SELECT {0} FROM {1} {2}".format(col_name, tbname, col_condi)
        print(col_sql)
    cursor.execute(col_sql)
    col_data = cursor.fetchall()
    cursor.close()
    return col_data

	data_list =[]
def save_data(rows):
    
    for row in range(0, len(rows)):
        data_list.append(rows[row][0])
    print("所選數據共有: ", len(rows), "筆")
    toshow = input("是否顯示所選數據? (輸入'Y' 或任意鍵跳過)")
    if toshow == 'Y' or toshow == 'y':
        print(data_list)
    else:
        print("電梯向下")
    return data_list
        
#Establish connection and Select data
def db_conn(username, password):
    server = 'sde2' 
    database = 'NTU_Creep' 
    cnxn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    cursor = cnxn.cursor()
    print("MS-SQL has connected")
    #選擇資料表
    tbname = get_table_name(cursor)
    #選擇欄位
    get_column_name(cursor, tbname)  
    #查詢欄位資料
    col_data = select_column(cursor, tbname)
    return col_data


#繪圖函式
def scatter(x,y):
    plt.scatter(x, y, marker='o', alpha= 0.3 ,color = 'blue')
    plt.show()


# In[12]:


#登入SQL，輸入帳密
user = 'tester'
print("Welcome! " + user)
#pwd = getpass.getpass("Please input password: ")
pwd = 'tester1115'

print("以下開始選取第一組數據")
#first_data_list
rows = db_conn(user, pwd)
list1 = save_data(rows)
print("--------------------")
print("以下開始選取第二組數據")
rows2 = db_conn(user, pwd)
list2 = save_data(rows2)

if len(list1) != len(list2):
    print("資料數量不同! 無法繪圖")
else:
    scatter(list1,list2)

