import time;
import threading;


>>> import matplotlib.pyplot as plt
>>> listx = [1,5, 7, 9,13,16];
>>> listy = [15,50,80,40,70,50]
>>> plt.plot(listx,listy);
[<matplotlib.lines.Line2D object at 0x000000000AC804E0>]
>>> plt.show();

#print('hello world');
#input("提示訊息視窗。");
# exit()

#Source:https://stackoverflow.com/questions/9012487/matplotlib-pyplot-savefig-outputs-blank-image
#Source:https://www.tutorialspoint.com/timer-objects-in-python
#Source:https://docs.microsoft.com/zh-tw/sql/connect/python/pyodbc/step-1-configure-development-environment-for-pyodbc-python-development?view=sql-server-2017
intIndex = 0;
def mytimer(): 
   #global intIndex += 1;
   print("經過" + str(intIndex) + "秒\n") 

my_timer = threading.Timer(5.0, mytimer) 
my_timer.start() 
print("倒數5秒開始\n")

#Source:https://codereview.stackexchange.com/questions/199743/countdown-timer-in-python
import time
import datetime
import timeit

def countdown_timer(x):
    while x >= 0 :
        x -= 1
        print("{} remaining".format(str(datetime.timedelta(seconds=x))))
        print("\n")
        time.sleep(1)


if __name__ == '__main__':
    print(timeit.timeit(lambda:countdown_timer(120), number=1)) 