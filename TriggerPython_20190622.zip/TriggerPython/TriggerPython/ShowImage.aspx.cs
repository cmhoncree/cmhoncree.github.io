﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TriggerPython
{
    public partial class ShowImage1 : System.Web.UI.Page
    {
        // 既有檔案儲存目錄相對路徑
        string strTmpFolder = @"C:\Tmpx\";
        string thumbnailImageFileName_Png = ".png";
        int int_Width = 640;
        int int_Height = 480;

        protected void Page_Load(object sender, EventArgs e)
        {
            // 取得系統編號
            string strsIndex = Convert.ToString(Request.QueryString["sIndex"]);
            string strNewsIndex = Convert.ToString(Request.QueryString["sIndex"]);

            string oriImgFilePath_Png = strTmpFolder + strsIndex + thumbnailImageFileName_Png;
            string newImgFilePath = strTmpFolder + strNewsIndex + thumbnailImageFileName_Png;

            writeImageToHtml(oriImgFilePath_Png, newImgFilePath, int_Width, int_Height, "png");
        }

        private void writeImageToHtml(string _oriImgFilePath, string _newImgFilePath, int _width, int _height, string _imgType)
        {
            // 建立 MemoryStream 物件
            System.IO.MemoryStream myStream = new System.IO.MemoryStream();

            // 建立 Bitmap 物件，代表原本的圖檔
            Bitmap oldBitmap = new Bitmap(_oriImgFilePath);

            // 建立 Bitmap 物件，代表新的圖檔，並設定特定的大小
            Bitmap newBitmap = new Bitmap(oldBitmap, _width, _height);

            // 釋放原本的圖檔
            oldBitmap.Dispose();

            // 將新的圖檔儲存至串流中
            if (_imgType == "jpeg")
            {
                newBitmap.Save(myStream, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            else if (_imgType == "jpg")
            {
                newBitmap.Save(myStream, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            else if (_imgType == "png")
            {
                newBitmap.Save(myStream, System.Drawing.Imaging.ImageFormat.Png);
            }
            else if (_imgType == "bmp")
            {
                newBitmap.Save(myStream, System.Drawing.Imaging.ImageFormat.Bmp);
            }
            else if (_imgType == "gif")
            {
                newBitmap.Save(myStream, System.Drawing.Imaging.ImageFormat.Gif);
            }

            // 建立 FileStream 物件，準備將上述串流中的資料寫出，以便產生新檔案
            System.IO.FileStream myFs = System.IO.File.OpenWrite(_newImgFilePath);
            // 將上述串流中的資料轉成 byte 陣列
            byte[] newBitmapData = myStream.ToArray();

            // 將串流中的資料寫出，以便產生新檔案
            myFs.Write(newBitmapData, 0, newBitmapData.Length);
            // 關閉 FileStream 物件
            myFs.Close();

            // 將新的圖檔轉成陣列資料
            byte[] bt = ReadAllBytesToArray(_newImgFilePath);

            // 停止圖片暫存機制
            HttpContext.Current.Response.Expires = 0;
            HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);

            // 將陣列資料寫入輸出資料流，以便顯示在畫面上
            HttpContext.Current.Response.BinaryWrite(bt);
            HttpContext.Current.Response.Flush();
        }

        private byte[] ReadAllBytesToArray(string path)
        {
            byte[] buffer = null;
            System.IO.FileStream stream = null;

            try
            {
                int offset = 0;
                stream = new System.IO.FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.Read);

                if (stream.Length > int.MaxValue)
                {
                    throw (new System.IO.IOException("檔案太大，無法下載，請確認。"));
                }

                int bytesToRead = Convert.ToInt32(stream.Length);
                buffer = new byte[stream.Length];

                while (bytesToRead > 0)
                {
                    int bytesRead = stream.Read(buffer, offset, bytesToRead);

                    if (bytesRead == 0)
                    {
                        throw new System.IO.IOException("非預期之檔案結尾，讀取檔案失敗!");
                    }

                    offset = (offset + bytesRead);
                    bytesToRead = (bytesToRead - bytesRead);
                }
            }
            finally
            {
                if (stream != null)
                {
                    stream.Close();
                }
            }

            return buffer;
        }
    }
}