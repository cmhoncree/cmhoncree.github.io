﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TriggerPython
{
    public partial class Sample001_Backup : System.Web.UI.Page
    {
        // 既有檔案儲存目錄相對路徑
        string strTmpFolder = @"D:\Tmpx\";
        string thumbnailImageFileName_Png = ".png";        

        protected void Page_Load(object sender, EventArgs e)
        {
            // 以 GUID 作為圖片檔案名稱
            string strsIndex = String.Empty;
            // string strNewsIndex = String.Empty;

            if (!Page.IsPostBack)
            {
                strsIndex = Guid.NewGuid().ToString();
                // strNewsIndex = Guid.NewGuid().ToString();

                ViewState["sIndex"] = strsIndex;
                // ViewState["NewsIndex"] = strNewsIndex;                
            }

            Img_Result.ImageUrl = "ShowImage.ashx?TimeStamp=" + DateTime.Now.ToString();
        }

        protected void Btn_Send_Click(object sender, EventArgs e)
        {
            string strsIndex = Convert.ToString(ViewState["sIndex"]);
            // string strNewsIndex = Convert.ToString(ViewState["NewsIndex"]);

            // string strTmpFolder = HttpContext.Current.Server.MapPath("~/Tmpx/");

            // string strCommand = strTmpFolder + "runPython.bat";
            // Lbl_Command.Text = strCommand + " " + strsIndex + " " + TxtBox_Shrinkagdt.Text + " " + TxtBox_shrinkage_strain.Text;
            // string oldImgFilePath = strTmpFolder + strsIndex + thumbnailImageFileName_Png;
            
            if (TxtBox_Shrinkagdt.Text != String.Empty && TxtBox_shrinkage_strain.Text != String.Empty)
            {
                // System.Diagnostics.Process.Start("cmd.exe");
                // System.Diagnostics.Process.Start(strCommand, strsIndex + " " + TxtBox_Shrinkagdt.Text + " " + TxtBox_shrinkage_strain.Text);

                /*
                while(true)
                {
                    if (System.IO.File.Exists(oldImgFilePath))
                    {                        
                        Img_Result.Visible = true;
                        break;
                    }
                    else
                    {
                        System.Threading.Thread.Sleep(3);
                    }
                }

                // Img_Result.ImageUrl = "ShowImage.ashx?sIndex=" + strsIndex + "&NewsIndex=" + strNewsIndex + "&TimeStamp =" + DateTime.Now.ToString();
                Img_Result.ImageUrl = "ShowImage.ashx?sIndex=" + strsIndex + "&TimeStamp =" + DateTime.Now.ToString();

                strsIndex = Guid.NewGuid().ToString();
                // strNewsIndex = Guid.NewGuid().ToString();

                ViewState["sIndex"] = strsIndex;
                // ViewState["NewsIndex"] = strNewsIndex;

                Img_Result.Visible = true;*/
            }
        }
    }
}