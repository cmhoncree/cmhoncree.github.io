﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TriggerPython
{
    public partial class Sample001 : System.Web.UI.Page
    {
        Ntu_CreepDataContext myNtu_CreepDataContext = new Ntu_CreepDataContext();
        // string strTempImageDir = "~/Tmpx/";

        protected void Page_Load(object sender, EventArgs e)
        {
            /*
            // 以 GUID 作為圖片檔案名稱
            string strsIndex = String.Empty;            

            if (!Page.IsPostBack)
            {
                // strsIndex = Guid.NewGuid().ToString();                
                // ViewState["sIndex"] = strsIndex;

                // Img_Result.ImageUrl = Page.ResolveUrl("~/ShowImage.ashx?sIndex=" + strsIndex + "&TimeStamp=" + Guid.NewGuid().ToString());
                // Lbl_Command.Text = Server.MapPath(strTempImageDir) + "!";
            } 
            */           
        }

        protected void Btn_Send_Click(object sender, EventArgs e)
        {
            string strsIndex = Guid.NewGuid().ToString();
            // string strOldsIndex = String.Empty;
            QueryConditionRecord myQueryConditionRecord = new QueryConditionRecord();

            if (TxtBox_Shrinkagdt.Text != String.Empty && TxtBox_shrinkage_strain.Text != String.Empty)
            {
                // strOldsIndex = strsIndex;
                myQueryConditionRecord.sIndex = strsIndex;
                myQueryConditionRecord.queryType = 1;
                myQueryConditionRecord.queryCondition1 = TxtBox_Shrinkagdt.Text;
                myQueryConditionRecord.queryCondition2 = TxtBox_shrinkage_strain.Text;
                myQueryConditionRecord.accessDateTime = DateTime.Now;
                myQueryConditionRecord.isDone = false;

                myNtu_CreepDataContext.QueryConditionRecord.InsertOnSubmit(myQueryConditionRecord);

                try
                {
                    myNtu_CreepDataContext.SubmitChanges();                    
                }
                catch (Exception ex)
                {                    
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "errorMsg", "alert('系統發生錯誤，錯誤訊息為:[" + ex.Message.Substring(0, ex.Message.IndexOf("。") == -1 ? ex.Message.Length : ex.Message.IndexOf("。")).Replace("'", "") + "]，請與系統管理者聯絡。', '系統訊息', 'error', '');", true);
                }

                // strsIndex = Guid.NewGuid().ToString();
                // ViewState["sIndex"] = strsIndex;

                myQueryConditionRecord = (from Item in myNtu_CreepDataContext.QueryConditionRecord
                                          where Item.sIndex == strsIndex
                                          select Item).FirstOrDefault();

                while (true)
                {
                    if (Convert.ToBoolean(myQueryConditionRecord.isDone))
                    {
                        // 設定圖片位置
                        // Img_Result.ImageUrl = Page.ResolveUrl("~/ShowImage.ashx?sIndex=" + strOldsIndex + "&TimeStamp=" + Guid.NewGuid().ToString());
                        // Img_Result.ImageUrl = Server.MapPath(strTempImageDir) + strOldsIndex + ".jpg";                        
                        // Img_Result.Visible = true;

                        Lit_Result.Text = "<img src=\"./Tmpx/" + strsIndex + ".jpg\" width=\"640\" height=\"480\"  />";
                        break;
                    }
                    else
                    {
                        System.Threading.Thread.Sleep(2);

                        myNtu_CreepDataContext = new Ntu_CreepDataContext();
                        myQueryConditionRecord = (from Item in myNtu_CreepDataContext.QueryConditionRecord
                                                  where Item.sIndex == strsIndex
                                                  select Item).FirstOrDefault();
                    }
                }                
            }
        }
    }
}